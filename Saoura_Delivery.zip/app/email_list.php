<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class email_list extends Model
{
    //
}
