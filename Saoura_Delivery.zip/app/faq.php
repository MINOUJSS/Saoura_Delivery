<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class faq extends Model
{
    // protected $fillable = [
    //     'consumer_id','name','email','question','answer','image'
    // ];
}
