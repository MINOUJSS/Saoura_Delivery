<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class about_us extends Model
{
    //
}
