<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class how_to_ship extends Model
{
    //
}
