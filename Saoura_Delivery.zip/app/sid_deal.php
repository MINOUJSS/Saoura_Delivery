<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sid_deal extends Model
{
    //
}
