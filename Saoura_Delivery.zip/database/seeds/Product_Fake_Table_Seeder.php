<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class Product_Fake_Table_Seeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $product=factory('App\product',100)->create();
    }
}
