<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class Sub_Sub_Category_Fake_Table_Seeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $sub_sub_category=factory('App\Sub_Sub_Category',20)->create();
    }
}
